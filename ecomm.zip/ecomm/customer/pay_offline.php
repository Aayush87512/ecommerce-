<center><!-- center Starts -->

<h1> Pay OffLine Using Method  </h1>

<p class="text-muted" >

If you have any questions, please feel free to <a href="../contact.php" >contact us,</a> our customer service center is working for you 24/7.

</p>

</center><!-- center Ends -->

<hr>


<div class="table-responsive" ><!-- table-responsive Starts -->

<table class="table table-bordered table-hover table-striped" ><!-- table table-bordered table-hover table-striped Starts -->

<thead><!-- thead Starts -->

<tr>

<th> Bank Account Details </th>

<th> sandip/ Details: </th>

<th> Western Union Details: </th>

</tr>

</thead><!-- thead Ends -->

<tbody><!-- tbody Starts -->

<tr>

<td> Bank Name:NBL <br>
    Account No:03333333 <br>
    Branch Code:055 <br>
    Branch:Dhulabari	 </td>

<td> NIC#123456 <br>
    Mobile No:9800000000 <br>
     Name:<strong> Sandip chapagain </strong></td>

<td> Name:<strong> Sandip Chapagain </strong>,<br>
 Mobile No:981602025,<br>
  Country:Nepal,<br>
   NIC No:001234567
</td>


</tr>

</tbody><!-- tbody Ends -->


</table><!-- table table-bordered table-hover table-striped Ends -->

</div><!-- table-responsive Ends -->