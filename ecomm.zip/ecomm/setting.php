<?php
$epay_url="https://uat.esewa.com.np/epay/main";
$pid="ThyloTech021";//product id must be unique
$sucess_url="https://brp.com.np/esewa/sucess.php?q=su";
$fail_url="https://brp.com.np/esewa/fail.php?q=fu";

//$sucess_url="https://sandipchapagain.com.np/";
//$fail_url="https://sandipchapagain.com.np/contactd.html";
?> 